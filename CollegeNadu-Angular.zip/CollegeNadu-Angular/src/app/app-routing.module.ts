import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import { ArticlesComponent } from './landing-pages/articles/articles.component';
// import { HomeComponent } from './landing-pages/home/home.component';

const routes: Routes = [
  {
    path: '', redirectTo: 'user', pathMatch: 'full'
  },
  {
    path:"auth", loadChildren: () => import('./../app/auth/auth.module'). then(m => m.AuthModule)
  },
  {
    path: 'user', loadChildren: () => import('../app/landing-pages/landing-pages.module').then(m => m.LandingPagesModule)
  },
  // {
  //   path: 'auth', loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule)
  // },
  // {
  //   path: 'home', component: ArticlesComponent
  // }
  // {
  //   path: '**', component: NotFoundComponent
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
