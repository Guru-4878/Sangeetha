import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LandingPagesRoutingModule } from './landing-pages-routing.module';
import { HomeComponent } from './home/home.component';
import { SharedModule } from '../shared/shared.module';
import { ArticlesComponent } from './articles/articles.component';


@NgModule({
  declarations: [HomeComponent, ArticlesComponent],
  imports: [
    CommonModule,
    LandingPagesRoutingModule,
    SharedModule
  ]
})
export class LandingPagesModule { }
